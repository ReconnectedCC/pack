![Jappa Computercraft Texturepack](https://i.imgur.com/O55yBzA.png)

# cc-jummit-textures

[Jummit](https://github.com/Jummit)'s textures for ComputerCraft that are more 
in line with the style of Mojang's new texture-artist, Jappa. Cherry-picked from
the [CC: Restitched](https://github.com/cc-tweaked/cc-restitched) repository, 
intended to be used with 
[CC: Tweaked](https://github.com/cc-tweaked/cc-tweaked).
